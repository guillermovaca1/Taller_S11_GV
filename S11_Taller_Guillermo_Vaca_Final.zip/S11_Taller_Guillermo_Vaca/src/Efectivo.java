public class Efectivo implements ProcesadorPago{
    @Override
    public void procesarPago(double monto) {
        System.out.println("Procesando pago con Efectivo por $" + monto);
    }
}
