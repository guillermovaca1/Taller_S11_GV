/* interfaz comun
ProcesadorPago con un metodo procesarPago que recibe como parametro un double monto
 */

public interface ProcesadorPago {
    public void procesarPago(double monto);
}
