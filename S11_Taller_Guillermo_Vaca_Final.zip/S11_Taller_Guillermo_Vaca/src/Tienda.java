public class Tienda {
    public void realizarPago(ProcesadorPago metodoPago, double monto) {
        metodoPago.procesarPago(monto);
        System.out.println("El pago fue realizado con exito!");
        System.out.println("Gracias por su compra");
    }
}
