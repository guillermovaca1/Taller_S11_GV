//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
/* Un sitema de pagos en una tienda: la tienda debe poder procesar pagos como tarjeta, paypal y efectivo, todos los metodos de pago se definen en una interfaz comun
ProcesadorPago con un metodo procesarPago que recibe como parametro un double monto, algunos metodos de pago requieren autenticacion de usuario
como tarjeta y paypal, estos metodos heredan de una clase abstracta PagoConAutenticacion que implementa la interfaz ProcesadorPago y tenga un atributo String
usuario, un metodo autenticar imprime un mensaje "se autentica un usuario" y esa clase tieen un metodo abstracto procesarPago que recibe como parametro un double monto
el metodo de efectivo no requiere una autenticacion entonces tiene uqe implementar directamente la interfaz procesadorpago, la clase teienda tiene que tenr un metodo
para realizar pagos que recibe 2 argumentos uno que es de metodopago y un monto, en el main se tiene uqe ingresar por consola el monto, un menu donde el usuario
elige el metodo de pago 1.Efectivo, 2.Tarjeta 3.PayPal 4.Cancelar en el metodo 2 y 3 se pide eñ usuario por consola solo despues de seleccionar el metodo de pago
se instancia el objeto de acuerdo a la opcion seleccionada
 */

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Tienda Tuti = new Tienda();
        System.out.println("--Bienvenido al sistema de pagos del Tuti--");
        System.out.print("Ingrese el monto a pagar: ");
        double monto = scanner.nextDouble();
        scanner.nextLine();

        while (true) {
            System.out.println("\n Elija la forma de pago porfavor:");
            System.out.println("1. Efectivo");
            System.out.println("2. Tarjeta");
            System.out.println("3. Paypal");
            System.out.println("4. Cancelar pago");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer
            ProcesadorPago metodoPago = null;
            switch (opcion) {
                case 1:
                    metodoPago = new Efectivo();
                    break;
                case 2:
                    System.out.print("Ingrese el usuario: ");
                    String usuarioTarjeta = scanner.nextLine();
                    metodoPago = new Tarjeta(usuarioTarjeta);
                    break;
                case 3:
                    System.out.print("Ingrese el usuario: ");
                    String usuarioPaypal = scanner.nextLine();
                    metodoPago = new Paypal(usuarioPaypal);
                    break;
                case 4:
                    System.out.println("Pago cancelado.");
                    return;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
                    continue;
            }

            Tuti.realizarPago(metodoPago, monto);
            break;
        }

        scanner.close();

    }
}