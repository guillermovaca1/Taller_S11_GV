public class Paypal extends PagoConAutenticacion{
    public Paypal(String usuario) {
        super(usuario);
    }
    @Override
    public void procesarPago(double monto) {
        autenticar();
        System.out.println("Procesando pago con PayPal por $" + monto);
    }

}
