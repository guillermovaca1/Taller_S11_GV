/*algunos metodos de pago requieren autenticacion de usuario
como tarjeta y paypal, estos metodos heredan de una clase abstracta PagoConAutenticacion que implementa la interfaz ProcesadorPago y
tenga un atributo String usuario, un metodo autenticar imprime un mensaje "se autentica un usuario"
y esa clase tieen un metodo abstracto procesarPago que recibe como parametro un double monto
*/

public abstract class PagoConAutenticacion implements ProcesadorPago {
    private String usuario;

    public PagoConAutenticacion(String usuario) {
        this.usuario = usuario;
    }

    public void autenticar() {
        System.out.println("El usuario: " + usuario + " fue autenticado con exito");
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public abstract void procesarPago(double monto);
}
