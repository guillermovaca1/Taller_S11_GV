public class Tarjeta extends PagoConAutenticacion{
    public Tarjeta(String usuario) {
        super(usuario);
    }
    @Override
    public void procesarPago(double monto) {
        autenticar();
        System.out.println("Procesando pago con Tarjeta por $" + monto);
    }

}
